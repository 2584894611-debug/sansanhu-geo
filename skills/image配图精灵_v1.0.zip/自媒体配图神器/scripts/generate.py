#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自媒体配图神器 - 图片生成脚本
调用速创API的GPT Image 2模型生成图片
"""

import requests
import json
import time
from typing import Optional, Dict

# ============== 配置 ==============
API_KEY = "xEPO3KS0lgwxtWpPB7UM3Jx5aq"
BASE_URL = "https://api.wuyinkeji.com"

# 提交任务接口
SUBMIT_URL = f"{BASE_URL}/api/async/image_gpt"

# 查询结果接口
QUERY_URL = f"{BASE_URL}/api/async/detail"

# 平台尺寸映射
PLATFORM_SIZES = {
    "小红书": "3:4",
    "抖音": "9:16",
    "视频号": "9:16",
    "公众号": "1:1",
    "通用": "16:9",
}

# 默认尺寸
DEFAULT_SIZE = "16:9"

# 轮询配置
MAX_POLL_COUNT = 10  # 最多轮询10次
POLL_INTERVAL = 3    # 每次间隔3秒


def translate_and_optimize_prompt(prompt: str) -> str:
    """
    将中文prompt翻译并优化为英文，提升GPT Image 2的生成效果
    
    Args:
        prompt: 用户输入的中文描述
        
    Returns:
        优化后的英文prompt
    """
    # 常用中文到英文的词汇映射
    cn_to_en = {
        "蓝天": "blue sky",
        "白云": "white clouds", 
        "草地": "lush green grass",
        "大海": "vast ocean",
        "日出": "sunrise",
        "日落": "sunset",
        "夜景": "night scene",
        "星空": "starry sky",
        "海边": "seaside",
        "沙滩": "beach",
        "森林": "forest",
        " mountains": "mountains",
        "河流": "river",
        "湖泊": "lake",
        "城市": "city",
        "街道": "street",
        "咖啡馆": "cozy cafe",
        "美食": "delicious food",
        "美女": "beautiful woman",
        "帅哥": "handsome man",
        "时尚": "fashion",
        "穿搭": "outfit",
        "旅行": "travel",
        "风景": "landscape",
        "人像": "portrait",
        "宠物": "cute pet",
        "猫咪": "cute cat",
        "狗狗": "cute dog",
        "花朵": "beautiful flowers",
        "春天": "spring",
        "夏天": "summer",
        "秋天": "autumn",
        "冬天": "winter",
        "温暖": "warm",
        "温馨": "cozy",
        "浪漫": "romantic",
        "梦幻": "dreamy",
        "清新": "fresh",
        "文艺": "artistic",
        "复古": "vintage",
        "简约": "minimalist",
        "高级": "high-end",
        "ins风": "ins style",
        "奶油风": "cream style",
        "极简": "minimalist",
        "ins风格": "instagram aesthetic",
        "氛围感": "atmospheric",
        "质感": "textured",
        "光影": "lighting",
        "柔光": "soft light",
        "暖色调": "warm tones",
        "冷色调": "cool tones",
    }
    
    # 质量增强词
    quality_boosters = [
        "high quality", "detailed", "professional",
        "beautiful lighting", "4K", "ultra realistic"
    ]
    
    optimized = prompt.strip()
    
    # 替换常见中文词汇
    for cn, en in cn_to_en.items():
        optimized = optimized.replace(cn, en)
    
    # 如果检测到主要是英文，直接使用
    # 如果包含中文，添加质量增强词
    has_chinese = any('\u4e00' <= char <= '\u9fff' for char in prompt)
    if has_chinese:
        # 添加质量后缀
        optimized = f"{optimized}, {', '.join(quality_boosters[:3])}"
    
    return optimized


def get_size_for_platform(platform: str) -> str:
    """
    根据平台获取图片尺寸
    
    Args:
        platform: 平台名称
        
    Returns:
        尺寸字符串
    """
    return PLATFORM_SIZES.get(platform, DEFAULT_SIZE)


def submit_image_task(prompt: str, size: str) -> Optional[str]:
    """
    提交图片生成任务
    
    Args:
        prompt: 英文优化后的prompt
        size: 图片尺寸
        
    Returns:
        任务ID，失败返回None
    """
    headers = {
        "Content-Type": "application/json",
        "Authorization": API_KEY
    }
    
    payload = {
        "prompt": prompt,
        "size": size
    }
    
    try:
        response = requests.post(
            SUBMIT_URL,
            params={"key": API_KEY},
            json=payload,
            headers=headers,
            timeout=30
        )
        
        result = response.json()
        
        if result.get("code") == 200 and result.get("data", {}).get("id"):
            task_id = result["data"]["id"]
            print(f"✓ 任务提交成功，任务ID: {task_id}")
            return task_id
        else:
            print(f"✗ 任务提交失败: {result.get('msg', '未知错误')}")
            return None
            
    except Exception as e:
        print(f"✗ 请求异常: {str(e)}")
        return None


def query_task_result(task_id: str) -> Dict:
    """
    查询任务结果
    
    Args:
        task_id: 任务ID
        
    Returns:
        结果字典，包含 status, images, message
    """
    headers = {
        "Content-Type": "application/json",
        "Authorization": API_KEY
    }
    
    try:
        response = requests.get(
            QUERY_URL,
            params={"key": API_KEY, "id": task_id},
            headers=headers,
            timeout=30
        )
        
        result = response.json()
        
        if result.get("code") == 200:
            data = result.get("data", {})
            return {
                "status": data.get("status", 0),
                "images": data.get("images", []),
                "message": data.get("message", "")
            }
        else:
            return {"status": -1, "images": [], "message": result.get("msg", "查询失败")}
            
    except Exception as e:
        return {"status": -1, "images": [], "message": f"查询异常: {str(e)}"}


def wait_for_result(task_id: str, max_attempts: int = MAX_POLL_COUNT) -> Optional[str]:
    """
    轮询等待图片生成结果
    
    Args:
        task_id: 任务ID
        max_attempts: 最大轮询次数
        
    Returns:
        图片URL，失败返回None
    """
    print(f"⏳ 正在生成图片，请稍候...")
    
    for attempt in range(max_attempts):
        time.sleep(POLL_INTERVAL)
        
        result = query_task_result(task_id)
        status = result["status"]
        
        if status == 2:  # 成功
            images = result.get("images", [])
            if images:
                print(f"✓ 图片生成成功!")
                return images[0]  # 返回第一张图片
            else:
                print(f"✗ 生成完成但无图片数据")
                return None
                
        elif status == 3:  # 失败
            print(f"✗ 图片生成失败: {result.get('message', '未知错误')}")
            return None
            
        elif status == -1:  # 查询异常
            print(f"✗ 查询失败: {result.get('message')}")
            return None
            
        else:
            # 0=初始化, 1=进行中
            print(f"⏳ 生成中... ({attempt + 1}/{max_attempts})")
    
    print(f"✗ 生成超时，请稍后重试")
    return None


def generate_image(prompt: str, platform: str = "通用") -> Optional[str]:
    """
    主函数：生成图片
    
    Args:
        prompt: 用户描述
        platform: 平台名称
        
    Returns:
        图片URL，失败返回None
    """
    print(f"\n{'='*50}")
    print(f"自媒体配图神器 - 图片生成")
    print(f"{'='*50}")
    print(f"平台: {platform}")
    print(f"原始描述: {prompt}")
    
    # 1. 获取尺寸
    size = get_size_for_platform(platform)
    print(f"图片尺寸: {size}")
    
    # 2. 优化prompt
    optimized_prompt = translate_and_optimize_prompt(prompt)
    print(f"优化Prompt: {optimized_prompt}")
    
    # 3. 提交任务
    task_id = submit_image_task(optimized_prompt, size)
    if not task_id:
        return None
    
    # 4. 轮询结果
    image_url = wait_for_result(task_id)
    
    print(f"\n{'='*50}")
    if image_url:
        print(f"生成的图片URL:\n{image_url}")
    print(f"{'='*50}\n")
    
    return image_url


def main():
    """测试入口"""
    # 测试用例
    test_cases = [
        ("周末下午茶时光，慵懒咖啡馆", "小红书"),
        ("穿搭分享，街头时尚", "抖音"),
        ("科技新品发布会现场", "公众号"),
        ("蓝天白云下的草原风景", "通用"),
    ]
    
    print("开始测试图片生成...\n")
    
    for prompt, platform in test_cases:
        result = generate_image(prompt, platform)
        if result:
            print(f"[成功] {platform} - {prompt}\n")
        else:
            print(f"[失败] {platform} - {prompt}\n")
        
        # 每个测试间隔5秒
        time.sleep(2)


if __name__ == "__main__":
    # 如果直接运行，执行测试
    # 如果被导入，提供函数接口
    import sys
    if len(sys.argv) > 1:
        # 命令行模式
        if len(sys.argv) >= 3:
            prompt = sys.argv[1]
            platform = sys.argv[2]
        else:
            prompt = sys.argv[1]
            platform = "通用"
        generate_image(prompt, platform)
    else:
        # 测试模式
        main()
