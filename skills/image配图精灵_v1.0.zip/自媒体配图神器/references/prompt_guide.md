# Prompt优化指南

> 让你的描述变成高质量图片的秘诀

## 为什么需要优化Prompt？

GPT Image 2 对英文Prompt的理解和生成效果更好。本技能会自动将你的中文描述翻译并优化为英文，同时添加质量增强词，让生成效果更出色。

## 平台配图风格指南

### 📱 小红书 (3:4 竖图)

**风格特点**：
- 高颜值、精致感
- 常用「ins风」「奶油风」「杂志感」
- 色调偏暖或小清新
- 适合生活方式的展示

**推荐描述词**：
```
- ins风咖啡馆，暖色调，木质家具，柔和光线
- 奶油色系卧室，简约风格，午后阳光
- 精致甜品台，马卡龙色系，玫瑰花装饰
- 穿搭分享，街头背景，时尚杂志风格
```

**场景示例**：
| 场景 | 优化后Prompt |
|------|-------------|
| 下午茶 | `afternoon tea, elegant dessert table, pastel colors, fresh flowers, soft natural lighting, high quality` |
| 穿搭 | `fashion outfit, stylish woman on city street, magazine cover style, professional photography` |
| 家居 | `cozy living room, cream color scheme, minimalist design, warm afternoon light, interior design magazine` |

---

### 🎵 抖音/视频号 (9:16 竖图)

**风格特点**：
- 冲击力强，第一眼抓眼球
- 常用「高级感」「氛围感」「电影感」
- 色彩对比度可以稍高
- 适合短视频封面

**推荐描述词**：
```
- 电影感，氛围感，高级感
- 赛博朋克，霓虹灯光，未来感
- 干净背景，纯色系，突出主体
- 情绪感，光影艺术，特写镜头
```

**场景示例**：
| 场景 | 优化后Prompt |
|------|-------------|
| 美食 | `mouthwatering food photography, gourmet dish, dark background, dramatic lighting, professional food styling` |
| 美妆 | `beauty portrait, flawless makeup, soft studio lighting, high-end cosmetic brand style` |
| 科技 | `futuristic tech gadget, neon lighting, cyberpunk aesthetic, dark background, product photography` |

---

### 📰 公众号 (1:1 方图)

**风格特点**：
- 信息清晰，阅读友好
- 常用「简洁」「专业」「商务」
- 适合知识类、干货类内容配图
- 可以稍显正式

**推荐描述词**：
```
- 商务会议，专业团队，现代办公室
- 数据图表插图风格，扁平化设计
- 书籍与咖啡，学术氛围，宁静
- 自然风光，大气磅礴，高清摄影
```

**场景示例**：
| 场景 | 优化后Prompt |
|------|-------------|
| 商务 | `professional business meeting, modern office, diverse team, corporate photography style, high quality` |
| 教育 | `open book, glasses, cozy study desk, warm lamp light, knowledge concept, detailed illustration` |
| 科技 | `futuristic technology concept, blue holographic interface, clean minimal background, digital art` |

---

### 🌐 通用横图 (16:9)

**风格特点**：
- 适用范围最广
- 风景、场景、banner图都适合
- 可以是大场景也可以是特写
- 最灵活的尺寸

**推荐描述词**：
```
- 壮丽风景，高清摄影，4K画质
- 城市天际线，日落时分，剪影
- 抽象艺术，现代设计，创意图案
- 温馨场景，生活气息，温暖色调
```

**场景示例**：
| 场景 | 优化后Prompt |
|------|-------------|
| 风景 | `breathtaking landscape, mountain range at sunset, golden hour lighting, cinematic view, 4K ultra detailed` |
| banner | `modern tech conference banner, abstract digital elements, blue and purple gradient, professional design` |
| 壁纸 | `desktop wallpaper, serene lake at dawn, misty atmosphere, peaceful, high resolution 4K` |

---

## 常用风格词汇表

### 🌈 色调风格
| 中文 | 英文 |
|------|------|
| 暖色调 | warm tones |
| 冷色调 | cool tones |
| 莫兰迪色 | Morandi colors, muted tones |
| 马卡龙色 | pastel colors, macaron tones |
| 高级灰 | sophisticated gray tones |
| 赛博朋克 | cyberpunk, neon colors |
| 复古胶片 | vintage film look |

### ✨ 质感描述
| 中文 | 英文 |
|------|------|
| 电影感 | cinematic, film grain |
| 杂志风 | magazine cover style |
| 奶油质感 | creamy texture |
| 丝绒质感 | velvet texture |
| 金属质感 | metallic texture |
| 磨砂质感 | matte finish |
| 玻璃质感 | glass effect |

### 💡 光影描述
| 中文 | 英文 |
|------|------|
| 柔光 | soft lighting |
| 逆光 | backlight, silhouette |
| 黄金时段 | golden hour |
| 蓝调时刻 | blue hour |
| 戏剧光 | dramatic lighting |
| 自然光 | natural daylight |
| 霓虹光 | neon lighting |

### 📐 构图描述
| 中文 | 英文 |
|------|------|
| 特写 | close-up, closeup shot |
| 全景 | panoramic view |
| 鸟瞰图 | bird's eye view |
| 对称构图 | symmetrical composition |
| 三分法 | rule of thirds |
| 留白 | minimalist, negative space |
| 中心构图 | centered composition |

---

## Prompt模板

### 基础模板
```
[主体] + [场景/背景] + [风格] + [色调] + [光影] + [质量词]
```

### 示例拆解

**输入**：生成一张小红书风格的咖啡馆下午茶图片

**拆解**：
- 主体：精致甜品、咖啡杯
- 场景：温馨咖啡馆
- 风格：ins风、精致
- 色调：暖色调、奶油色系
- 光影：柔和自然光
- 质量词：high quality, detailed

**优化后**：
```
elegant afternoon tea set, cozy cafe interior, ins style, pastel colors, warm tones, soft natural lighting, fresh flowers, high quality, detailed, professional photography
```

---

## 常见问题

### Q: 描述太长会怎样？
A: 建议控制在50-150个英文单词，过长的描述可能导致生成不稳定。

### Q: 如何生成纯文字图片？
A: 可以描述「纯色背景 + 大字文字」，但GPT Image 2的文字生成能力有限，建议谨慎使用。

### Q: 生成的图片比例可以调整吗？
A: 可以！本技能预设了各平台最佳比例。如需自定义，可在描述中说明，如「竖版构图 portrait orientation」。

### Q: 如何避免生成风格不稳定？
A: 
1. 风格描述要具体明确
2. 避免同时使用风格冲突的词汇
3. 添加参考词如「consistent style」「cohesive design」

### Q: 生成的人像不满意怎么办？
A:
1. 描述更具体的场景和动作
2. 添加光线描述「soft studio lighting」
3. 指定风格「fashion magazine cover」
4. 多尝试几次，每次稍微调整描述

---

## 进阶技巧

### 1. 情绪板(Mood Board)描述法
```
[情绪关键词] + [参考风格] + [核心元素]
```
示例：
```
`whimsical, dreamy, fairytale aesthetic, enchanted forest, magical atmosphere, soft focus, ethereal lighting`
```

### 2. 摄影参数描述法
```
[焦距] + [光圈] + [光线] + [风格]
```
示例：
```
`shot with 85mm lens, f/1.8, golden hour, bokeh background, portrait photography, professional`
```

### 3. 艺术风格参考法
```
[主体] + inspired by [艺术家/流派] + style
```
示例：
```
`landscape painting inspired by Bob Ross, peaceful mountain scene, soft brushstrokes, oil painting style`
```

---

> 💡 **小贴士**：本技能的自动优化已经很强大了！你只需要用自然语言描述你想要的场景，技能会自动翻译和优化。如果追求更精确的效果，可以参考以上指南手动添加风格描述词。
